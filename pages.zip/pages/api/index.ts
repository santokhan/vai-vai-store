import { NextApiRequest, NextApiResponse } from 'next';

export default async function (req: NextApiRequest, res: NextApiResponse<{ message: string }>) {
    res.status(200).json({ message: "Welcome to NEXTJS route" })
}
