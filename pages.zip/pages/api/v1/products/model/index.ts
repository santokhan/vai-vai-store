// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, Model } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async (req: NextApiRequest, res: NextApiResponse<Model | Model[]>) => {
    if (req.method === 'GET') {
        const model = await prisma.model.findMany();
        res.status(200).json(model)
    } else if (req.method === 'POST') {
        const createdmodel = await prisma.model.create({
            data: {
                model: req.body.type,
                brandId: req.body.type
            },
        })
        res.status(200).json(createdmodel)
    } else {
        res.status(405).json([]);
    }
}
