// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, ProductType, Model } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async (req: NextApiRequest, res: NextApiResponse<Model | {}>) => {
    if (req.method === 'GET') {
        if (typeof req.query.id === 'string') {
            const model = await prisma.model.findFirst({ where: { id: req.query.id } });
            if (model) {
                res.status(200).json(model)
            } else {
                res.status(200).json({});
            }
        } else {
            res.status(405).json({});
        }
    } else {
        res.status(405).json({});
    }
}
