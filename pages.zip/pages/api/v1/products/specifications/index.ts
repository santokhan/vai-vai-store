// pages/api/v1/products/specifications
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, ProductType, Specifications } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<Specifications | Specifications[]>) {
    if (req.method === 'GET') {
        const specifications = await prisma.specifications.findMany();
        res.status(200).json(specifications)
    } else if (req.method === 'POST') {
        const createdspecifications = await prisma.specifications.create({
            data: {
                modelId: req.body.modelId,
                phoneType: req.body.phoneType,
                color: req.body.color,
                storage: req.body.storage,
            },
        })
        res.status(200).json(createdspecifications)
    } else {
        res.status(405).json([]);
    }
}
