// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, ProductType, Specifications } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<Specifications | {}>) {
    if (req.method === 'GET') {
        if (typeof req.query.id === 'string') {
            const specifications = await prisma.specifications.findFirst({ where: { id: req.query.id } });
            if (specifications) {
                res.status(200).json(specifications)
            } else {
                res.status(200).json({});
            }
        } else {
            res.status(405).json({});
        }
    } else {
        res.status(405).json({});
    }
}
