`http://localhost:3000/api/v1/products/model`
