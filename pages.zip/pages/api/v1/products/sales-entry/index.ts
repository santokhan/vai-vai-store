// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, SalesEntry } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async (req: NextApiRequest, res: NextApiResponse<SalesEntry | SalesEntry[]>) => {
    if (req.method === 'GET') {
        const salesEntry = await prisma.salesEntry.findMany();
        res.status(200).json(salesEntry)
    } else if (req.method === 'POST') {
        const createdsalesEntry = await prisma.salesEntry.create({
            data: {
                IMEI: req.body.IMEI,
                price: req.body.price,
                modelId: req.body.modelId,
                specificationsId: req.body.specificationsId,
                customerId: req.body.customerId,
            },
        })
        res.status(200).json(createdsalesEntry)
    } else {
        res.status(405).json([]);
    }
}
