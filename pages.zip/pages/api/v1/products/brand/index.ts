// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { Brand, PrismaClient } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<Brand | Brand[]>) {
    if (req.method === 'GET') {
        const brand = await prisma.brand.findMany();
        res.status(200).json(brand);
    } else if (req.method === 'POST') {
        const createdBrand = await prisma.brand.create({
            data: {
                brandName: req.body.brandName,
                productTypeId: req.body.productTypeId
            },
        })
        res.status(200).json(createdBrand);
    } else {
        res.status(405).json([]);
    }
}
