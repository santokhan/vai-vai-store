// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { Brand, PrismaClient } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<Brand | {}>) {
    if (req.method === 'GET') {
        if (typeof req.query.id === 'string') {
            const brand = await prisma.brand.findFirst({ where: { id: req.query.id } });
            if (brand) {
                res.status(200).json(brand)
            } else {
                res.status(404).json({})
            }
        }
    } else {
        res.status(405).json({});
    }
}
