// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, ProductType } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<ProductType | {}>) {
    if (req.method === 'GET') {
        if (typeof req.query.id === 'string') {
            const productType = await prisma.productType.findFirst({ where: { id: req.query.id } });
            if (productType) {
                res.status(200).json(productType)
            } else {
                res.status(404).json({})
            }
        }
    } else {
        res.status(405).json({});
    }
}
