// pages/api/users.js
// import { PrismaClient } from '@prisma/client';
import { PrismaClient, ProductType } from '@/prisma/generated/client';
import { NextApiRequest, NextApiResponse } from 'next';

const prisma = new PrismaClient();

export default async function (req: NextApiRequest, res: NextApiResponse<ProductType | ProductType[]>) {
    if (req.method === 'GET') {
        const productType = await prisma.productType.findMany();
        res.status(200).json(productType)
    } else if (req.method === 'POST') {
        const createdProductType = await prisma.productType.create({
            data: {
                type: req.body.type,
            },
        })
        res.status(200).json(createdProductType)
    } else {
        res.status(405).json([]);
    }
}
